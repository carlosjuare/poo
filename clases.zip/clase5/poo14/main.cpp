#include <QApplication>
#include"log.h"
#include"formulario.h"

int main(int a,char*b[]){
    QApplication app(a,b);
    ven login;


    login.show();


        return app.exec();




}
