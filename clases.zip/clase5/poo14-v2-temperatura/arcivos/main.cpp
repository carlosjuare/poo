#include <QApplication>
#include"log.h"
#include"formulario.h"
#include<admindb.h>

int main(int a,char*b[]){
    QApplication app(a,b);
    ven login;


    login.show();



        return app.exec();





}
